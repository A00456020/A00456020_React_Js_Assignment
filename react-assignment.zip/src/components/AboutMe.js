import React from 'react';
const AboutMe = ()=> {
return(
<>
<h1>Hi, I am Parth Tarak Vaidya.</h1>
<p>I am from India. I graduated with a Computer Engineering Degree from Gujarat, India. 
<br/>Ever since I was a child, I have loved computers, mainly coding, video games and operating systems. I am a fan of open source software development.</p>

<p> During my final year in Undergraduate studies, I worked on project based on Deep Learning and Natural Language Processing.
    This provided me with an exposure to Data Science and Analysis of data to yield patterns. This desire fueled me and motivated me to pursue
    a degree in Computing and Data Analytics at The Saint Mary's University, Halifax, Nova Scotia, Canada.
</p>
</>
);
}
export default AboutMe;